//
//  ViewController.swift
//  iOS_QRreader
//
//  Created by SONG YUN-HO on 2020/12/09.
//  Copyright © 2019 swieeft. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {
    
    @IBOutlet weak var scanner:Scanner!
    @IBOutlet weak var startBtn:UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.scanner.delegate = self
        
        self.startBtn.layer.masksToBounds = true
        self.startBtn.layer.cornerRadius = 10 // 버튼 테두리
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        if !self.scanner.isRunning{
            self.scanner.stop(btnClick: false)
        }
    }
    
    @IBAction func btnStart(_ sender: UIButton){
        if self.scanner.isRunning{
            startBtn.setTitle("START", for: .normal)
            self.scanner.stop(btnClick: true)
        }
        else{
            self.scanner.start()
            startBtn.setTitle("STOP", for: .normal)
        }
        
        sender.isSelected = self.scanner.isRunning
    }
}

extension ViewController: ScannerDelegate{
    func scannerStatus(status: ScannerStatus) {

        var title = ""
        var message = ""
        switch status {
        case let .success(code):
            guard let code = code else {
                title = "에러"
                message = "QR코드 or 바코드를 인식하지 못했습니다.\n다시 시도해주세요."
                break
            }
            title = "알림"
            message = "인식성공\n\(code)"
        case .fail:
            title = "에러"
            message = "QR코드 or 바코드를 인식하지 못했습니다.\n다시 시도해주세요."
        case let .stop(btnClick):
            if btnClick {
                title = "알림"
                message = "바코드 읽기를 멈추었습니다."
                self.startBtn.isSelected = scanner.isRunning
            } else {
                self.startBtn.isSelected = scanner.isRunning
                return
            }
        }

        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "확인", style: .default, handler: nil)

        alert.addAction(okAction)
        self.present(alert, animated: true, completion: nil)
    }
}

