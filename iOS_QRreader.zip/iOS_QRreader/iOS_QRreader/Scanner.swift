//
//  Scanner.swift
//  iOS_QRreader
//
//  Created by SONG YUN-HO on 2020/12/09.
//  Copyright © 2019 swieeft. All rights reserved.
//

import AVFoundation
import UIKit

enum ScannerStatus{
    case success(_ code: String?)
    case fail
    case stop(_ btnClick: Bool)
}

protocol ScannerDelegate: class {
    func scannerStatus(status: ScannerStatus)
}

class Scanner: UIView{
    
    weak var delegate: ScannerDelegate?
    
    var previewLayer: AVCaptureVideoPreviewLayer?
    var guideLineView: UIView?
    
    var captureSession: AVCaptureSession?
    
    var isRunning: Bool{
        guard let session = self.captureSession else{
            return false
        }
        return session.isRunning
    }
    
    let metadataObjectTypes: [AVMetadataObject.ObjectType] = [.upce, .code39, .code39Mod43, .code93, .code128, .ean8, .ean13, .aztec, .pdf417, .itf14, .dataMatrix, .interleaved2of5, .qr] // 인식할 코드 타입
    
    override init(frame: CGRect) {
        super.init(frame: frame)

        self.initialSetupView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)

        self.initialSetupView()
    }
    
    private func initialSetupView(){
        self.captureSession = AVCaptureSession()
        
        guard let captureDevice = AVCaptureDevice.default(for: .video) else {
            return
        }
        
        let deviceInput: AVCaptureDeviceInput
        
        do{
            deviceInput = try AVCaptureDeviceInput(device: captureDevice)
        } catch let error{
            print(error.localizedDescription)
            print("error")
            return
        }
        
        guard let captureSession = self.captureSession else {
            self.fail()
            return
        }
        
        if captureSession.canAddInput(deviceInput) {
            captureSession.addInput(deviceInput)
        } else {
            self.fail()
            return
        }
        
        let metadataOutput = AVCaptureMetadataOutput()
        
        if captureSession.canAddOutput(metadataOutput) {
            captureSession.addOutput(metadataOutput)
            
            metadataOutput.setMetadataObjectsDelegate(self, queue: DispatchQueue.main)
            metadataOutput.metadataObjectTypes = self.metadataObjectTypes
        } else {
            self.fail()
            return
        }
        
        self.setPreviewLayer()
        self.setGuideLineView()
    }
    
    private func setPreviewLayer(){
        guard let captureSession = self.captureSession else{
            return
        }
        
        let previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
        previewLayer.videoGravity = AVLayerVideoGravity.resizeAspectFill
        previewLayer.frame = self.layer.bounds
        
        self.layer.addSublayer(previewLayer)
        self.previewLayer = previewLayer
    }
    
    private func setGuideLineView(){
        let centerGuideLineView = UIView()
        centerGuideLineView.translatesAutoresizingMaskIntoConstraints = false
        centerGuideLineView.backgroundColor = #colorLiteral(red: 0.9254902005, green: 0.2352941185, blue: 0.1019607857, alpha: 1)
        self.addSubview(centerGuideLineView)
        self.bringSubviewToFront(centerGuideLineView)

        centerGuideLineView.trailingAnchor.constraint(equalTo: self.trailingAnchor).isActive = true
        centerGuideLineView.leadingAnchor.constraint(equalTo: self.leadingAnchor).isActive = true
        centerGuideLineView.centerYAnchor.constraint(equalTo: self.centerYAnchor).isActive = true
        centerGuideLineView.heightAnchor.constraint(equalToConstant: 1).isActive = true

        self.guideLineView = centerGuideLineView
    }
}

extension Scanner{
    func start(){
        self.captureSession?.startRunning()
    }
    
    func stop(btnClick: Bool){
        self.captureSession?.stopRunning()
        self.delegate?.scannerStatus(status: .stop(btnClick))
    }
    
    func fail(){
        self.delegate?.scannerStatus(status: .fail)
        self.captureSession = nil
    }
    
    func found(code: String){
        self.delegate?.scannerStatus(status: .success(code))
    }
}

extension Scanner: AVCaptureMetadataOutputObjectsDelegate{
    func metadataOutput(_ output: AVCaptureMetadataOutput, didOutput metadataObjects: [AVMetadataObject], from connection: AVCaptureConnection) {
        
        stop(btnClick: false)
        
        if let metadataObject = metadataObjects.first {
            guard let readableObject = metadataObject as? AVMetadataMachineReadableCodeObject,
                let stringValue = readableObject.stringValue else {
                return
            }
            AudioServicesPlaySystemSound(SystemSoundID(kSystemSoundID_Vibrate))
            found(code: stringValue)
        }
    }
}
